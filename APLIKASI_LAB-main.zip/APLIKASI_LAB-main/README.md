## Selamat datang di APLIKASI LAB!

Aplikasi LAB adalah platform digital untuk mengelola laboratorium klinis rumah sakit secara efisien. Aplikasi ini mengotomatisasi pendaftaran pasien, pemrosesan hasil tes, dan distribusi laporan real-time, terintegrasi dengan sistem rumah sakit untuk layanan yang cepat, akurat, dan transparan. Dengan fitur seperti manajemen data, pelacakan hasil, dan notifikasi, aplikasi ini mengurangi antrean, meminimalkan kesalahan, serta mempercepat komunikasi, meningkatkan pengalaman pengguna dan layanan berbasis teknologi.

# Profile Developer
1. Rania Devi Viantasari (23050974118)
2. Muhammad Aji Yoga Pratama (23050974130)
3. Iklil Jumala (23050974133)

Project Aplikasi LAB ini kami buat untuk memenuhi tugas akhir semester mata kuliah Pemrograman Mobile Prodi S1 Pendidikan Teknologi Informasi [Pendidikan Teknologi Informasi](https://pendidikan-ti.ft.unesa.ac.id/) dari Fakultas Teknik [Fakultas Teknik](https://ft.unesa.ac.id/) Universitas Negeri Surabaya [Universitas Negeri Surabaya](https://unesa.ac.id/) 
