package com.example.myapplicationlab.Model;

public class Status {
    String id;
    String status;

    public Status() {
    }

    public Status(String id, String status) {
        this.id = id;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
